package main.intergalactic;

import main.intergalactic.InputProcess;
class MerchantGuide {

	public static void main(String[] args) 
	{
	   new InputProcess("D:\\Galaxy\\src\\main\\intergalactic\\FileInput");
        }
}
